from django.contrib.auth.models import User
from django.db import models


class APIKey(models.Model):
    user = models.ForeignKey(User)
    key = models.CharField(maxlength=64)

    class Admin:
        pass

    def __str__(self):
        return '%s -- %s' % (self.user, self.key)