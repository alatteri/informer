from django.conf import settings
from django.conf.urls.defaults import *


urlpatterns = patterns('apps.crudapi.views',
    (r'^([^/]+)/([^/]+)/$', 'otherwise'),
    (r'^([^/]+)/([^/]+)/(.+)/$', 'existing'),
    # Cheap fall backs for anything without PUT/DELETE
    (r'^([^/]+)/([^/]+)/add/$', 'add'),
    (r'^([^/]+)/([^/]+)/(.+)/delete/$', 'delete'),
)


if settings.DEBUG:
    urlpatterns += patterns ('',
        (r'^test/$', 'django.views.generic.simple.direct_to_template', {'template': 'api/test.html'}),
    )