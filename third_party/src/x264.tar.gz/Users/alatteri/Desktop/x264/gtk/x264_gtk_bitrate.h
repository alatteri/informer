#ifndef __X264_GTK_BITRATE_H__
#define __X264_GTK_BITRATE_H__


GtkWidget *_bitrate_page (X264_Gui_Config *config);


#endif /* __X264_GTK_BITRATE_H__ */
