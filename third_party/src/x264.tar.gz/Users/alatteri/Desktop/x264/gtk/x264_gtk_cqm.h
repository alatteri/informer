#ifndef __X264_GTK_CQM_H__
#define __X264_GTK_CQM_H__


GtkWidget *_cqm_page (X264_Gui_Config *config);


#endif /* __X264_GTK_CQM_H__ */
