#ifndef __X264_GTK_ENCODE_MAIN_WINDOW_H__
#define __X264_GTK_ENCODE_MAIN_WINDOW_H__


void x264_gtk_encode_main_window ();


#endif /* __X264_GTK_ENCODE_MAIN_WINDOW_H__ */
