#ifndef __X264_GTK_MORE_H__
#define __X264_GTK_MORE_H__


GtkWidget *_more_page (X264_Gui_Config *config);


#endif /* __X264_GTK_MORE_H__ */
