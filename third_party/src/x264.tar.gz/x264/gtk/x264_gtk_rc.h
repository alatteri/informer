#ifndef __X264_GTK_RC_H__
#define __X264_GTK_RC_H__


GtkWidget *_rate_control_page (X264_Gui_Config *config);


#endif /* __X264_GTK_RC_H__ */
