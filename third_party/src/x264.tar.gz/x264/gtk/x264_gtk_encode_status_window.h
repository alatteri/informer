#ifndef __X264_GTK_ENCODE_STATUS_WINDOW_H__
#define __X264_GTK_ENCODE_STATUS_WINDOW_H__


GtkWidget *x264_gtk_encode_status_window (X264_Thread_Data *thread_data);


#endif /* __X264_GTK_ENCODE_STATUS_WINDOW_H__ */
