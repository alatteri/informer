#ifndef __X264_GTK_MB_H__
#define __X264_GTK_MB_H__


GtkWidget *_mb_page (X264_Gui_Config *config);


#endif /* __X264_GTK_MB_H__ */
