#ifndef __X264_GTK_ENCODE_ENCODE_H__
#define __X264_GTK_ENCODE_ENCODE_H__


gpointer x264_gtk_encode_encode (X264_Thread_Data *thread_data);


#endif /* __X264_GTK_ENCODE_ENCODE_H__ */
